
import talib.abstract as ta
import pandas as pd
from freqtrade.strategy import IStrategy

class MeanReversion_v1(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = "1h"
    minimal_roi = {"0": 0.1, "100": 0.05, "500": 0}
    stoploss = -0.12
    def populate_indicators(self, dataframe, metadata):
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['ema_trend'] = ta.EMA(dataframe, timeperiod=150)
        return dataframe
    def populate_entry_trend(self, dataframe, metadata):
        dataframe.loc[(dataframe['rsi'] < 25) & (dataframe['close'] > dataframe['ema_trend']), 'enter_long'] = 1
        return dataframe
    def populate_exit_trend(self, dataframe, metadata):
        dataframe.loc[(dataframe['rsi'] > 75) | (dataframe['close'] < dataframe['ema_trend']), 'exit_long'] = 1
        return dataframe
