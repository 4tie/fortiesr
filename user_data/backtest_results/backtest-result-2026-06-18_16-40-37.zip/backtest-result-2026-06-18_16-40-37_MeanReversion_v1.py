import talib.abstract as ta
import pandas as pd
from freqtrade.strategy import IStrategy, IntParameter


class MeanReversion_v1(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = "1h"

    minimal_roi = {"0": 0.564, "352": 0.17, "999": 0.033, "2190": 0}
    stoploss = -0.162

    rsi_oversold = IntParameter(20, 35, default=24, space="buy")
    rsi_overbought = IntParameter(65, 80, default=74, space="sell")
    ema_period = IntParameter(100, 300, default=167, space="buy")

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['ema_trend'] = ta.EMA(dataframe, timeperiod=int(self.ema_period.value))
        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe.loc[
            (dataframe['rsi'] < self.rsi_oversold.value) &
            (dataframe['close'] > dataframe['ema_trend']),
            'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe.loc[
            (dataframe['rsi'] > self.rsi_overbought.value),
            'exit_long'] = 1
        return dataframe
