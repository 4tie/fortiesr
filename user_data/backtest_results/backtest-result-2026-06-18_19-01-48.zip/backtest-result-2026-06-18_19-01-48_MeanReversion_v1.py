import talib.abstract as ta
import pandas as pd
from freqtrade.strategy import IStrategy


class MeanReversion_v1(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = "5m"

    minimal_roi = {"0": 0.247, "23": 0.058, "72": 0.022, "190": 0}
    stoploss = -0.13
    max_open_trades = 5

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['ema2000'] = ta.EMA(dataframe, timeperiod=2000)
        dataframe['ema50'] = ta.EMA(dataframe, timeperiod=50)
        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        buy = (
            # Signal A: deep oversold bounce in uptrend
            ((dataframe['rsi'] < 22) & (dataframe['close'] > dataframe['ema2000'])) |
            # Signal B: dip to EMA2000 support, slowing RSI
            (
                (dataframe['close'] < dataframe['ema2000']) &
                (dataframe['close'] > dataframe['ema2000'] * 0.99) &
                (dataframe['close'].shift(1) > dataframe['ema2000'].shift(1)) &
                (dataframe['rsi'] > 30) & (dataframe['rsi'] < 50) &
                (dataframe['close'] > dataframe['ema50'])
            )
        )
        dataframe.loc[buy, 'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe['exit_long'] = 0
        return dataframe
