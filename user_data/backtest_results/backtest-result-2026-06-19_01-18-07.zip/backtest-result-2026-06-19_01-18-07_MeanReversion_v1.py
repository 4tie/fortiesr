import talib.abstract as ta
import pandas as pd
from freqtrade.strategy import IStrategy, IntParameter


class MeanReversion_v1(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = "5m"

    minimal_roi = {"0": 0.181, "31": 0.035, "54": 0.01, "130": 0}
    stoploss = -0.345

    buy_rsi_threshold = IntParameter(18, 28, default=24, space='buy')
    buy_ema_period = IntParameter(1000, 2500, default=1458, space='buy')

    max_open_trades = 5

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['ema'] = ta.EMA(dataframe, timeperiod=self.buy_ema_period.value)
        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe.loc[
            (dataframe['rsi'] < self.buy_rsi_threshold.value) &
            (dataframe['close'] > dataframe['ema']),
            'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe['exit_long'] = 0
        return dataframe
