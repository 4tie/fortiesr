import talib.abstract as ta
import pandas as pd
from freqtrade.strategy import IStrategy, IntParameter


class MeanReversion_v1(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = "1h"

    minimal_roi = {"0": 0.564, "352": 0.17, "999": 0.033, "2190": 0}
    stoploss = -0.12

    rsi_oversold = IntParameter(20, 35, default=24, space="buy")
    rsi_overbought = IntParameter(65, 80, default=74, space="sell")

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['ema200'] = ta.EMA(dataframe, timeperiod=200)
        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe.loc[
            (dataframe['rsi'] < self.rsi_oversold.value) &
            (dataframe['close'] > dataframe['ema200']),
            'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe.loc[
            (dataframe['rsi'] > self.rsi_overbought.value),
            'exit_long'] = 1
        return dataframe
