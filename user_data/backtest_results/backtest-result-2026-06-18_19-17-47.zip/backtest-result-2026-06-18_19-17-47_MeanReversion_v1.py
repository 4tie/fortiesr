import talib.abstract as ta
import pandas as pd
from freqtrade.strategy import IStrategy


class MeanReversion_v1(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = "5m"

    minimal_roi = {"0": 0.10, "10": 0.05, "30": 0.02, "60": 0}
    stoploss = -0.13
    max_open_trades = 5

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['ema100'] = ta.EMA(dataframe, timeperiod=100)
        dataframe['ema2000'] = ta.EMA(dataframe, timeperiod=2000)
        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe.loc[
            (dataframe['rsi'] < 22) &
            (dataframe['close'] > dataframe['ema100']) &
            (dataframe['close'] > dataframe['ema2000']),
            'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe['exit_long'] = 0
        return dataframe

    def custom_exit(self, pair: str, trade, current_time, current_rate, current_profit, **kwargs):
        if current_profit < 0 and (current_time - trade.open_date_utc).total_seconds() / 3600 > 48:
            return 'time_stop'
        return None
