import talib.abstract as ta
import pandas as pd
from freqtrade.strategy import IStrategy


class MeanReversion_v1(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = "5m"

    minimal_roi = {"0": 0.01, "30": 0.005, "120": 0}
    stoploss = -0.05

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['ema_long'] = ta.EMA(dataframe, timeperiod=1000)
        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe.loc[
            (dataframe['rsi'] < 25) &
            (dataframe['close'] > dataframe['ema_long']),
            'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe.loc[
            (dataframe['rsi'] > 70),
            'exit_long'] = 1
        return dataframe
