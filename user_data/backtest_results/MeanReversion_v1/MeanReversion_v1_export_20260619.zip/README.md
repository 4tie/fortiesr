# MeanReversion_v1

Freqtrade-ready intraday strategy. RSI<22 mean reversion with EMA2000 macro trend filter.

## Performance (2-year: 2024-01-01 to 2026-01-01)

| Metric | Value |
|--------|-------|
| Net Profit | +7.31% |
| Profit Factor | 1.20 |
| Total Trades | 357 |
| Win Rate | 74.5% |
| Max Drawdown | ~9% |

## Setup

```bash
freqtrade backtesting --strategy MeanReversion_v1 --config config.json --timerange 20240101-20260101 --timeframe 5m
```

## Strategy Logic

- Entry: RSI(14) < 22 AND close > EMA(2000)
- Exit: timed ROI exit at 0% after ~3h (or sooner at higher profit targets)
- Stoploss: -13%
- Max open trades: 4 (one per pair)
- Pairs: LTC/USDT, XRP/USDT, BNB/USDT, LINK/USDT
- Timeframe: 5m
